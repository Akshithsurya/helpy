const DEFAULT_PRESETS = {
  work: { title: 'Work Session', duration: 60, goal: 'Focus on work tasks' },
  study: { title: 'Study Session', duration: 45, goal: 'Focus on studying' },
  focus: { title: 'Deep Focus', duration: 25, goal: 'Deep focus session' },
  'focus session': { title: 'Deep Focus', duration: 25, goal: 'Deep focus session' },
  code: { title: 'Coding Session', duration: 90, goal: 'Write code and solve problems' },
  design: { title: 'Design Session', duration: 60, goal: 'Create and refine designs' },
  write: { title: 'Writing Session', duration: 45, goal: 'Write articles, docs, or content' },
  read: { title: 'Reading Session', duration: 30, goal: 'Read and learn new things' },
  exercise: { title: 'Exercise Session', duration: 45, goal: 'Physical activity or workout' },
  meditate: { title: 'Meditation Session', duration: 15, goal: 'Practice mindfulness and meditation' },
  clean: { title: 'Cleaning Session', duration: 30, goal: 'Clean and organize space' },
  review: { title: 'Review Session', duration: 45, goal: 'Review work or materials' },
  plan: { title: 'Planning Session', duration: 30, goal: 'Plan and organize tasks' },
};

function parsePlanArguments(args) {
  const trimmedArgs = args.trim();
  const parts = trimmedArgs ? trimmedArgs.split(/\s+/) : [];
  let title = 'Planned session';
  let durationMinutes = 30;
  let goal = '';
  let usedPreset = null;

  if (trimmedArgs) {
    const normalizedArgs = trimmedArgs.toLowerCase();
    const preset = Object.keys(DEFAULT_PRESETS)
      .sort((a, b) => b.length - a.length)
      .find((presetName) => {
        return normalizedArgs === presetName || normalizedArgs.startsWith(`${presetName} `);
      });

    if (preset) {
      const presetConfig = DEFAULT_PRESETS[preset];
      title = presetConfig.title;
      durationMinutes = presetConfig.duration;
      goal = presetConfig.goal;
      usedPreset = preset;
      const remainingArgs = trimmedArgs.slice(preset.length).trim();
      if (remainingArgs) {
        parts.splice(0, parts.length, ...remainingArgs.split(/\s+/));
      } else {
        parts.length = 0;
      }
    }
  }

  if (parts.length > 0) {
    const remainingArgs = parts.join(' ');
    const durationMatch = remainingArgs.match(/(\d+)(?:\s*(?:min|minutes?|m))?/i);

    if (durationMatch) {
      durationMinutes = parseInt(durationMatch[1], 10);
      const customTitle = remainingArgs.replace(durationMatch[0], '').trim();
      if (customTitle) {
        title = customTitle;
      }
    } else {
      title = remainingArgs;
    }
  }

  durationMinutes = Math.max(5, Math.min(240, durationMinutes));

  return {
    title,
    goal,
    durationMinutes,
    usedPreset,
  };
}

function breakDownIntoTasks(planConfig, chunkSizeMinutes = 15) {
  const totalDuration = planConfig.durationMinutes || 30;
  const goal = planConfig.goal || planConfig.title || '';
  const tasks = [];
  const numChunks = Math.ceil(totalDuration / chunkSizeMinutes);

  if (numChunks === 1) {
    tasks.push({
      id: `task-${Date.now()}-0`,
      title: goal || planConfig.title || 'Focus session',
      durationMinutes: totalDuration,
      completed: false,
      completedAt: null,
    });
  } else {
    for (let i = 0; i < numChunks; i++) {
      const duration = i < numChunks - 1 
        ? chunkSizeMinutes 
        : totalDuration - (i * chunkSizeMinutes);
      tasks.push({
        id: `task-${Date.now()}-${i}`,
        title: `${goal || planConfig.title || 'Focus'} - Part ${i + 1}`,
        durationMinutes: duration,
        completed: false,
        completedAt: null,
      });
    }
  }

  return tasks;
}

function createPlanConfig(planArgs, chunkSizeMinutes = 15) {
  const parsed = parsePlanArguments(planArgs);
  const tasks = breakDownIntoTasks(parsed, chunkSizeMinutes);
  return {
    title: parsed.title,
    goal: parsed.goal,
    durationMinutes: parsed.durationMinutes,
    tasks,
    chunkSizeMinutes,
    nextQueue: [],
    source: 'extension',
    createdAt: new Date().toISOString(),
  };
}

if (typeof module !== 'undefined') {
  module.exports = {
    DEFAULT_PRESETS,
    parsePlanArguments,
    breakDownIntoTasks,
    createPlanConfig,
  };
}
