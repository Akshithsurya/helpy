const DEFAULT_INACTIVITY_MINUTES = 10;
const DEFAULT_NOTIFICATION_INTERVAL_MINUTES = 5;
const CHECK_INTERVAL_MS = 5000;
const SETTINGS_SYNC_INTERVAL_MS = 60000;
const BRIDGE_SYNC_INTERVAL_MS = 30000;
const HISTORY_FLUSH_INTERVAL_MS = 60000;
const APP_BASE_URL = 'http://localhost:3456';

class EnhancedTabTracker {
  constructor() {
    this.tabSessions = {};
    this.tabHistory = [];
    this.domainTime = {};
    this.switchCount = 0;
    this.maxTabs = 20;
    this.notifyOnMaxTabs = true;
    this.lastMaxTabNotification = 0;
  }

  async init() {
    if (typeof chrome === 'undefined' || !chrome || !chrome.storage) {
      console.warn('Chrome storage not available, skipping EnhancedTabTracker init');
      return;
    }
    const result = await chrome.storage.local.get([
      'tabSessions',
      'tabHistory',
      'domainTime',
      'switchCount',
      'maxTabs',
      'notifyOnMaxTabs',
    ]);
    this.tabSessions = result.tabSessions || {};
    this.tabHistory = result.tabHistory || [];
    this.domainTime = result.domainTime || {};
    this.switchCount = result.switchCount || 0;
    this.maxTabs = result.maxTabs || 20;
    this.notifyOnMaxTabs = result.notifyOnMaxTabs !== false;
  }

  async save() {
    await chrome.storage.local.set({
      tabSessions: this.tabSessions,
      tabHistory: this.tabHistory.slice(-1000),
      domainTime: this.domainTime,
      switchCount: this.switchCount,
      maxTabs: this.maxTabs,
      notifyOnMaxTabs: this.notifyOnMaxTabs,
    });
  }

  startSession(tabId, url, title) {
    const now = Date.now();
    const domain = this.extractDomain(url);

    if (this.tabSessions[tabId]) {
      this.endSession(tabId);
    }

    this.tabSessions[tabId] = {
      tabId,
      url,
      title,
      domain,
      startTime: now,
      lastActive: now,
    };

    this.switchCount++;
  }

  updateActivity(tabId) {
    if (this.tabSessions[tabId]) {
      this.tabSessions[tabId].lastActive = Date.now();
    }
  }

  endSession(tabId) {
    const session = this.tabSessions[tabId];
    if (!session) return null;

    const now = Date.now();
    const duration = now - session.startTime;

    if (duration > 3000) {
      const historyEntry = {
        tabId: session.tabId,
        url: session.url,
        title: session.title,
        domain: session.domain,
        startTime: session.startTime,
        endTime: now,
        duration: duration,
      };

      this.tabHistory.push(historyEntry);

      if (!this.domainTime[session.domain]) {
        this.domainTime[session.domain] = 0;
      }
      this.domainTime[session.domain] += duration;
    }

    delete this.tabSessions[tabId];
    this.save();
    return duration;
  }

  extractDomain(url) {
    try {
      if (!url || url.startsWith('chrome://') || url.startsWith('chrome-extension://')) {
        return null;
      }
      return new URL(url).hostname.replace(/^www\./, '');
    } catch {
      return null;
    }
  }

  async checkTabCount() {
    if (!this.notifyOnMaxTabs) return;

    const [tabs] = await Promise.all([chrome.tabs.query({ currentWindow: true })]);

    if (tabs.length > this.maxTabs) {
      const now = Date.now();
      if (now - this.lastMaxTabNotification > 60000) {
        chrome.notifications.create({
          type: 'basic',
          iconUrl: 'icon.png',
          title: 'Too many tabs!',
          message: `You have ${tabs.length} tabs open. Consider closing some to stay focused.`,
          priority: 2,
        });
        this.lastMaxTabNotification = now;
      }
    }
  }

  getTimeReport(days = 1) {
    const cutoff = Date.now() - days * 24 * 60 * 60 * 1000;
    const filteredHistory = this.tabHistory.filter((h) => h.startTime > cutoff);

    const domainStats = {};
    filteredHistory.forEach((entry) => {
      if (!domainStats[entry.domain]) {
        domainStats[entry.domain] = {
          domain: entry.domain,
          totalTime: 0,
          visits: 0,
        };
      }
      domainStats[entry.domain].totalTime += entry.duration;
      domainStats[entry.domain].visits++;
    });

    return {
      domainStats: Object.values(domainStats).sort((a, b) => b.totalTime - a.totalTime),
      totalTime: filteredHistory.reduce((sum, e) => sum + e.duration, 0),
      switchCount: this.switchCount,
      activeSessions: Object.values(this.tabSessions),
    };
  }
}

class PomodoroTimer {
  constructor() {
    this.isRunning = false;
    this.isBreak = false;
    this.focusDuration = 25 * 60 * 1000;
    this.breakDuration = 5 * 60 * 1000;
    this.longBreakDuration = 15 * 60 * 1000;
    this.cyclesBeforeLongBreak = 4;
    this.cycleCount = 0;
    this.remainingTime = 0;
    this.startTime = 0;
    this.endTime = 0;
    this.blockNonWorkTabs = false;
  }

  async init() {
    if (typeof chrome === 'undefined' || !chrome || !chrome.storage) {
      console.warn('Chrome storage not available, skipping PomodoroTimer init');
      return;
    }
    const result = await chrome.storage.sync.get([
      'pomodoroRunning',
      'pomodoroIsBreak',
      'pomodoroRemaining',
      'pomodoroStart',
      'pomodoroEnd',
      'pomodoroCycleCount',
      'pomodoroFocusDuration',
      'pomodoroBreakDuration',
      'pomodoroLongBreakDuration',
      'pomodoroCyclesBeforeLongBreak',
      'pomodoroBlockNonWork',
    ]);

    this.focusDuration = result.pomodoroFocusDuration || this.focusDuration;
    this.breakDuration = result.pomodoroBreakDuration || this.breakDuration;
    this.longBreakDuration = result.pomodoroLongBreakDuration || this.longBreakDuration;
    this.cyclesBeforeLongBreak = result.pomodoroCyclesBeforeLongBreak || this.cyclesBeforeLongBreak;
    this.blockNonWorkTabs = result.pomodoroBlockNonWork || false;

    if (result.pomodoroRunning) {
      this.isRunning = true;
      this.isBreak = result.pomodoroIsBreak;
      this.cycleCount = result.pomodoroCycleCount || 0;
      this.remainingTime = result.pomodoroRemaining;
      this.startTime = result.pomodoroStart;
      this.endTime = result.pomodoroEnd;

      const elapsed = Date.now() - this.startTime;
      this.remainingTime = Math.max(0, this.endTime - Date.now());

      if (this.remainingTime <= 0) {
        this.completeSession();
      } else {
        this.scheduleCompletion();
      }
    }
  }

  async save() {
    await chrome.storage.sync.set({
      pomodoroRunning: this.isRunning,
      pomodoroIsBreak: this.isBreak,
      pomodoroRemaining: this.remainingTime,
      pomodoroStart: this.startTime,
      pomodoroEnd: this.endTime,
      pomodoroCycleCount: this.cycleCount,
      pomodoroFocusDuration: this.focusDuration,
      pomodoroBreakDuration: this.breakDuration,
      pomodoroLongBreakDuration: this.longBreakDuration,
      pomodoroCyclesBeforeLongBreak: this.cyclesBeforeLongBreak,
      pomodoroBlockNonWork: this.blockNonWorkTabs,
    });
  }

  startFocus() {
    this.isRunning = true;
    this.isBreak = false;
    this.startTime = Date.now();
    this.remainingTime = this.focusDuration;
    this.endTime = this.startTime + this.remainingTime;
    this.scheduleCompletion();
    this.save();
    this.broadcastState();

    chrome.notifications.create({
      type: 'basic',
      iconUrl: 'icon.png',
      title: 'Focus session started!',
      message: 'Stay focused for 25 minutes.',
      priority: 2,
    });
  }

  startBreak() {
    this.isRunning = true;
    this.isBreak = true;
    this.cycleCount++;
    this.startTime = Date.now();
    this.remainingTime =
      this.cycleCount % this.cyclesBeforeLongBreak === 0
        ? this.longBreakDuration
        : this.breakDuration;
    this.endTime = this.startTime + this.remainingTime;
    this.scheduleCompletion();
    this.save();
    this.broadcastState();

    chrome.notifications.create({
      type: 'basic',
      iconUrl: 'icon.png',
      title: 'Break time!',
      message:
        this.cycleCount % this.cyclesBeforeLongBreak === 0
          ? 'Take a long break - you earned it!'
          : 'Take a short break and stretch.',
      priority: 2,
    });
  }

  pause() {
    this.remainingTime = this.endTime - Date.now();
    this.isRunning = false;
    this.clearAlarm();
    this.save();
    this.broadcastState();
  }

  resume() {
    if (!this.isRunning && this.remainingTime > 0) {
      this.isRunning = true;
      this.startTime = Date.now();
      this.endTime = this.startTime + this.remainingTime;
      this.scheduleCompletion();
      this.save();
      this.broadcastState();
    }
  }

  stop() {
    this.isRunning = false;
    this.isBreak = false;
    this.remainingTime = 0;
    this.clearAlarm();
    this.save();
    this.broadcastState();
  }

  completeSession() {
    this.isRunning = false;

    if (!this.isBreak) {
      chrome.notifications.create({
        type: 'basic',
        iconUrl: 'icon.png',
        title: 'Focus session complete!',
        message: 'Great job! Time for a break.',
        priority: 2,
      });
      this.startBreak();
    } else {
      chrome.notifications.create({
        type: 'basic',
        iconUrl: 'icon.png',
        title: 'Break complete!',
        message: 'Ready to focus again?',
        priority: 2,
      });
      this.cycleCount = 0;
      this.save();
      this.broadcastState();
    }
  }

  scheduleCompletion() {
    this.clearAlarm();
    chrome.alarms.create('pomodoro-complete', {
      when: this.endTime,
    });
  }

  clearAlarm() {
    chrome.alarms.clear('pomodoro-complete');
  }

  broadcastState() {
    chrome.runtime
      .sendMessage({
        type: 'POMODORO_STATE_UPDATE',
        state: this.getState(),
      })
      .catch(() => {});
  }

  getState() {
    const now = Date.now();
    let remaining = this.remainingTime;
    if (this.isRunning) {
      remaining = Math.max(0, this.endTime - now);
    }

    return {
      isRunning: this.isRunning,
      isBreak: this.isBreak,
      remainingTime: remaining,
      cycleCount: this.cycleCount,
      blockNonWorkTabs: this.blockNonWorkTabs,
    };
  }
}

const DEFAULT_PRESETS = {
  work: { title: 'Work Session', duration: 60, goal: 'Focus on work tasks' },
  study: { title: 'Study Session', duration: 45, goal: 'Focus on studying' },
  focus: { title: 'Deep Focus', duration: 25, goal: 'Deep focus session' },
  'focus session': { title: 'Deep Focus', duration: 25, goal: 'Deep focus session' },
};

class CommandHandler {
  constructor(backgroundContext) {
    this.background = backgroundContext;
    this.commands = this.registerCommands();
  }

  registerCommands() {
    return {
      plan: {
        description: 'Plan your tasks and goals',
        suggestions: ['plan work', 'plan study', 'plan focus', "plan today's tasks"],
        handler: this.handlePlanCommand.bind(this),
      },
      pomodoro: {
        description: 'Control the Pomodoro timer',
        suggestions: ['pomodoro start', 'pomodoro stop', 'pomodoro break'],
        handler: this.handlePomodoroCommand.bind(this),
      },
      report: {
        description: 'Open time usage reports',
        suggestions: ['report today', 'report week'],
        handler: this.handleReportCommand.bind(this),
      },
      help: {
        description: 'Show available commands',
        suggestions: ['help'],
        handler: this.handleHelpCommand.bind(this),
      },
      track: {
        description: 'Start tracking an activity',
        suggestions: ['track focus', 'track work'],
        handler: this.handleTrackCommand.bind(this),
      },
      settings: {
        description: 'Open extension settings',
        suggestions: ['settings'],
        handler: this.handleSettingsCommand.bind(this),
      },
    };
  }

  getSuggestions(text) {
    const suggestions = [];
    const searchText = text.toLowerCase().trim();

    for (const [name, cmd] of Object.entries(this.commands)) {
      if (name.startsWith(searchText) || searchText === '') {
        cmd.suggestions.forEach((suggestion) => {
          suggestions.push({
            content: suggestion,
            description: cmd.description,
          });
        });
      }
    }

    return suggestions.slice(0, 5);
  }

  parsePlanArguments(args) {
    const trimmedArgs = args.trim();
    const parts = trimmedArgs ? trimmedArgs.split(/\s+/) : [];
    let title = 'Planned session';
    let durationMinutes = 30;
    let goal = '';
    let usedPreset = null;

    if (trimmedArgs) {
      const normalizedArgs = trimmedArgs.toLowerCase();
      const preset = Object.keys(DEFAULT_PRESETS)
        .sort((a, b) => b.length - a.length)
        .find((presetName) => {
          return normalizedArgs === presetName || normalizedArgs.startsWith(`${presetName} `);
        });

      if (preset) {
        const presetConfig = DEFAULT_PRESETS[preset];
        title = presetConfig.title;
        durationMinutes = presetConfig.duration;
        goal = presetConfig.goal;
        usedPreset = preset;
        const remainingArgs = trimmedArgs.slice(preset.length).trim();
        if (remainingArgs) {
          parts.splice(0, parts.length, ...remainingArgs.split(/\s+/));
        } else {
          parts.length = 0;
        }
      }
    }

    if (parts.length > 0) {
      const remainingArgs = parts.join(' ');
      const durationMatch = remainingArgs.match(/(\d+)(?:\s*(?:min|minutes?|m))?/i);

      if (durationMatch) {
        durationMinutes = parseInt(durationMatch[1], 10);
        const customTitle = remainingArgs.replace(durationMatch[0], '').trim();
        if (customTitle) {
          title = customTitle;
        }
      } else {
        title = remainingArgs;
      }
    }

    durationMinutes = Math.max(5, Math.min(240, durationMinutes));

    return {
      title: title,
      goal: goal,
      durationMinutes: durationMinutes,
      usedPreset: usedPreset,
    };
  }

  async handleCommand(text) {
    const parts = text.trim().split(/\s+/);
    const commandName = parts[0].toLowerCase();
    const args = parts.slice(1).join(' ');

    if (this.commands[commandName]) {
      return await this.commands[commandName].handler(args);
    }

    return {
      action: 'showNotification',
      title: 'Unknown Command',
      message: `Unknown command: ${commandName}. Type "help" to see available commands.`,
      options: { duration: 3000 },
    };
  }

  async handlePlanCommand(args) {
    const parsedArgs = this.parsePlanArguments(args);

    const planConfig = {
      title: parsedArgs.title,
      goal: parsedArgs.goal,
      durationMinutes: parsedArgs.durationMinutes,
      nextQueue: [],
      source: 'omnibox',
      createdAt: new Date().toISOString(),
    };

    if (this.background && this.background.dataTrackingManager) {
      this.background.dataTrackingManager.record('task_completion', 1, {
        action: 'plan_created',
        type: parsedArgs.usedPreset || 'custom',
      });
    }

    try {
      const response = await postToApp('/api/focus-plan', planConfig);
      if (response.ok) {
        const result = await response.json();
        const syncedPlan = result.plan || planConfig;
        activeFocusTask = syncedPlan.title || planConfig.title;
        broadcastStateUpdate();
        return {
          action: 'showNotification',
          title: 'Plan Created!',
          message: `Starting ${activeFocusTask} for ${syncedPlan.durationMinutes || planConfig.durationMinutes} minutes in Helpy.`,
          options: { duration: 3000 },
          planConfig: syncedPlan,
          syncStatus: 'synced',
        };
      }
    } catch (error) {
      console.error('Error sending plan to app:', error);
      const isUnauthorized =
        bridgeStatus === 'unauthorized' || error.message?.includes('status: 401');
      activeFocusTask = planConfig.title;
      broadcastStateUpdate();
      return {
        action: 'showNotification',
        title: isUnauthorized ? 'Plan Sync Failed' : 'Plan Saved Locally',
        message: isUnauthorized
          ? `Saved ${planConfig.title} locally, but Helpy rejected the bridge session. Refresh the app connection and try again.`
          : `Saved ${planConfig.title} for ${planConfig.durationMinutes} minutes, but the Helpy app is unavailable.`,
        options: { duration: 5000 },
        planConfig,
        syncStatus: isUnauthorized ? 'auth-error' : 'local-only',
      };
    }

    activeFocusTask = planConfig.title;
    broadcastStateUpdate();
    return {
      action: 'showNotification',
      title: 'Plan Saved Locally',
      message: `Saved ${planConfig.title} for ${planConfig.durationMinutes} minutes, but the Helpy app did not confirm the sync.`,
      options: { duration: 5000 },
      planConfig,
      syncStatus: 'local-only',
    };
  }

  async handlePomodoroCommand(args) {
    const action = args.toLowerCase().trim();

    if (action === 'start' || action === 'focus') {
      pomodoroTimer.startFocus();
      return {
        action: 'showNotification',
        title: 'Pomodoro',
        message: 'Focus session started!',
        options: { duration: 3000 },
      };
    } else if (action === 'break') {
      pomodoroTimer.startBreak();
      return {
        action: 'showNotification',
        title: 'Pomodoro',
        message: 'Break time!',
        options: { duration: 3000 },
      };
    } else if (action === 'stop' || action === 'pause') {
      if (pomodoroTimer.isRunning) {
        pomodoroTimer.pause();
      }
      return {
        action: 'showNotification',
        title: 'Pomodoro',
        message: 'Timer paused.',
        options: { duration: 3000 },
      };
    } else if (action === 'resume') {
      pomodoroTimer.resume();
      return {
        action: 'showNotification',
        title: 'Pomodoro',
        message: 'Timer resumed.',
        options: { duration: 3000 },
      };
    } else if (action === 'reset') {
      pomodoroTimer.stop();
      return {
        action: 'showNotification',
        title: 'Pomodoro',
        message: 'Timer reset.',
        options: { duration: 3000 },
      };
    }

    return {
      action: 'showNotification',
      title: 'Pomodoro',
      message: 'Available: start, break, pause, resume, reset',
      options: { duration: 4000 },
    };
  }

  async handleReportCommand(args) {
    chrome.tabs.create({
      url: 'reports.html',
    });
    return {
      action: 'none',
      title: '',
      message: '',
      options: {},
    };
  }

  async handleHelpCommand(args) {
    const helpText = Object.entries(this.commands)
      .map(([name, cmd]) => `${name} - ${cmd.description}`)
      .join('\n');

    return {
      action: 'showNotification',
      title: 'Available Commands',
      message: helpText,
      options: { duration: 5000 },
    };
  }

  async handleTrackCommand(args) {
    const trackType = args.toLowerCase().trim() || 'focus';

    if (this.background && this.background.dataTrackingManager) {
      this.background.dataTrackingManager.record('user_behavior', 1, {
        action: 'tracking_started',
        type: trackType,
      });
    }

    return {
      action: 'showNotification',
      title: 'Tracking Started',
      message: `Now tracking: ${trackType}`,
      options: { duration: 3000 },
    };
  }

  async handleSettingsCommand(args) {
    if (chrome.runtime.openOptionsPage) {
      chrome.runtime.openOptionsPage();
    }

    return {
      action: 'none',
      title: '',
      message: '',
      options: {},
    };
  }
}

class SimpleDataTrackingManager {
  constructor() {
    this.records = [];
    this.enabled = true;
  }

  record(trackingItemId, value, metadata = {}) {
    if (!this.enabled) return null;

    const record = {
      trackingItemId,
      timestamp: Date.now(),
      value,
      metadata,
    };
    this.records.push(record);

    if (this.records.length > 1000) {
      this.records = this.records.slice(-500);
    }

    return record;
  }

  getRecords(trackingItemId, options = {}) {
    let records = trackingItemId
      ? this.records.filter((r) => r.trackingItemId === trackingItemId)
      : [...this.records];

    if (options.startTime) {
      records = records.filter((r) => r.timestamp >= options.startTime);
    }
    if (options.endTime) {
      records = records.filter((r) => r.timestamp <= options.endTime);
    }
    if (options.limit) {
      records = records.slice(-options.limit);
    }

    return records;
  }
}

let dataTrackingManager = new SimpleDataTrackingManager();
let tabTracker = new EnhancedTabTracker();
let pomodoroTimer = new PomodoroTimer();

let tabActivity = {};
let tabLastNotified = {};
let inactivityDuration = DEFAULT_INACTIVITY_MINUTES * 60 * 1000;
let notificationIntervalDuration = DEFAULT_NOTIFICATION_INTERVAL_MINUTES * 60 * 1000;
let isPaused = false;
let displayName = '';
let bridgeToken = '';
let appConnected = false;
let bridgeStatus = 'disconnected';
let checkTimer = null;
let lastSettingsSync = 0;
let activeFocusTask = null;

// Google Auth
let googleUser = null; // { email, name, picture, sub, accessToken }
let googleAccessToken = null;

async function googleLogin() {
  try {
    // Note: You need to set up OAuth credentials in Google Cloud Console
    // and add the extension ID to the authorized origins
    const clientId = 'YOUR_GOOGLE_CLIENT_ID.apps.googleusercontent.com'; // TODO: Replace with actual client ID
    const redirectUri = chrome.identity.getRedirectURL();
    const authUrl = new URL('https://accounts.google.com/o/oauth2/v2/auth');
    authUrl.searchParams.set('client_id', clientId);
    authUrl.searchParams.set('redirect_uri', redirectUri);
    authUrl.searchParams.set('response_type', 'token');
    authUrl.searchParams.set('scope', 'openid email profile');
    authUrl.searchParams.set('state', Math.random().toString(36).substring(2, 15));

    const authResultUrl = await chrome.identity.launchWebAuthFlow({
      url: authUrl.toString(),
      interactive: true,
    });

    // Parse the access token from the redirect URL
    const urlParams = new URLSearchParams(authResultUrl.split('#')[1]);
    googleAccessToken = urlParams.get('access_token');

    // Fetch user info
    const userInfoResponse = await fetch('https://www.googleapis.com/oauth2/v2/userinfo', {
      headers: {
        Authorization: `Bearer ${googleAccessToken}`,
      },
    });

    if (!userInfoResponse.ok) {
      throw new Error('Failed to fetch user info');
    }

    googleUser = await userInfoResponse.json();

    // Save to local storage
    await chrome.storage.local.set({
      googleUser,
      googleAccessToken,
    });

    // Sync to app
    if (appConnected) {
      try {
        await postToApp('/api/auth/google', { googleUser, accessToken: googleAccessToken });
      } catch (e) {
        console.error('Error syncing Google user to app:', e);
      }
    }

    broadcastStateUpdate();
    return { success: true, user: googleUser };
  } catch (error) {
    console.error('Google login error:', error);
    return { success: false, error: error.message };
  }
}

async function googleLogout() {
  try {
    googleUser = null;
    googleAccessToken = null;
    await chrome.storage.local.remove(['googleUser', 'googleAccessToken']);
    broadcastStateUpdate();
    return { success: true };
  } catch (error) {
    console.error('Google logout error:', error);
    return { success: false, error: error.message };
  }
}

let tabVisitHistory = [];
let currentVisit = null;

// Only run immediate initialization in real Chrome extension context, not in tests
if (typeof module === 'undefined' || !module.exports) {
  // Load Google auth from local storage first
  chrome.storage.local.get(['googleUser', 'googleAccessToken'], (localResult) => {
    try {
      if (localResult.googleUser) {
        googleUser = localResult.googleUser;
      }
      if (localResult.googleAccessToken) {
        googleAccessToken = localResult.googleAccessToken;
      }
    } catch (e) {
      console.error('Error loading Google auth:', e);
    }
  });

  chrome.storage.sync.get(
    ['inactivityMinutes', 'notificationIntervalMinutes', 'isPaused', 'displayName', 'bridgeToken'],
    (result) => {
      try {
        applyStoredSettings(result);
        startChecking();
        syncDisplayNameFromApp(true);
        tabTracker.init();
        pomodoroTimer.init();
      } catch (error) {
        console.error('Error initializing extension:', error);
      }
    }
  );
}

chrome.storage.onChanged.addListener((changes, namespace) => {
  if (namespace !== 'sync') {
    return;
  }

  try {
    if (changes.inactivityMinutes?.newValue) {
      const minutes = parseInt(changes.inactivityMinutes.newValue, 10);
      if (!isNaN(minutes) && minutes >= 1 && minutes <= 1440) {
        inactivityDuration = minutes * 60 * 1000;
      }
    }

    if (changes.notificationIntervalMinutes?.newValue) {
      const minutes = parseInt(changes.notificationIntervalMinutes.newValue, 10);
      if (!isNaN(minutes) && minutes >= 1 && minutes <= 1440) {
        notificationIntervalDuration = minutes * 60 * 1000;
      }
    }

    if (changes.isPaused) {
      isPaused = Boolean(changes.isPaused.newValue);
    }

    if (changes.displayName) {
      displayName = sanitizeDisplayName(changes.displayName.newValue);
    }

    if (changes.bridgeToken) {
      bridgeToken = sanitizeBridgeToken(changes.bridgeToken.newValue);
    }
  } catch (error) {
    console.error('Error handling storage change:', error);
  }
});

function applyStoredSettings(result = {}) {
  try {
    if (result.inactivityMinutes) {
      const minutes = parseInt(result.inactivityMinutes, 10);
      if (!isNaN(minutes) && minutes >= 1 && minutes <= 1440) {
        inactivityDuration = minutes * 60 * 1000;
      }
    }

    if (result.notificationIntervalMinutes) {
      const minutes = parseInt(result.notificationIntervalMinutes, 10);
      if (!isNaN(minutes) && minutes >= 1 && minutes <= 1440) {
        notificationIntervalDuration = minutes * 60 * 1000;
      }
    }

    if (result.isPaused !== undefined) {
      isPaused = Boolean(result.isPaused);
    }

    displayName = sanitizeDisplayName(result.displayName);
    bridgeToken = sanitizeBridgeToken(result.bridgeToken);
  } catch (error) {
    console.error('Error applying stored settings:', error);
  }
}

function sanitizeBridgeToken(value) {
  if (typeof value !== 'string') {
    return '';
  }
  return value.trim().slice(0, 256);
}

function getBridgeHeaders(extraHeaders = {}) {
  return {
    'Content-Type': 'application/json',
    ...(bridgeToken ? { 'X-Helpy-Bridge-Token': bridgeToken } : {}),
    ...extraHeaders,
  };
}

function setBridgeStatus(nextStatus) {
  const normalizedStatus =
    nextStatus === 'connected' || nextStatus === 'unauthorized' ? nextStatus : 'disconnected';
  const nextConnected = normalizedStatus === 'connected';
  const statusChanged = bridgeStatus !== normalizedStatus || appConnected !== nextConnected;

  bridgeStatus = normalizedStatus;
  appConnected = nextConnected;

  if (statusChanged) {
    broadcastStateUpdate();
  }
}

function saveBridgeToken(nextToken) {
  const sanitized = sanitizeBridgeToken(nextToken);
  if (!sanitized || sanitized === bridgeToken) {
    return;
  }

  bridgeToken = sanitized;
  chrome.storage.sync.set({ bridgeToken }, () => {
    if (chrome.runtime.lastError) {
      console.error('Error saving bridge token:', chrome.runtime.lastError);
    }
  });
}

function isCurrentExtensionSession(data = {}) {
  try {
    // Check if chrome and chrome.runtime.id are available
    const hasChromeRuntimeId = typeof chrome !== 'undefined' && chrome && chrome.runtime && chrome.runtime.id;
    if (!hasChromeRuntimeId) {
      console.warn('Chrome runtime not available, cannot verify extension session');
      return false;
    }
    
    // Check multiple possible places for registeredExtensionId
    const possibleIds = [
      data?.registeredExtensionId,
      data?.bridge?.registeredExtensionId, 
      data?.extensionSettings?.registeredExtensionId
    ].filter(Boolean);
    
    // If there are no registered extension IDs yet, any extension can connect
    if (possibleIds.length === 0) {
      return true;
    }
    
    // Otherwise, check if any ID matches current extension ID
    return possibleIds.some(id => id && id === chrome.runtime.id);
  } catch (e) {
    console.warn('Error checking extension session:', e);
    return false;
  }
}

async function postToApp(path, payload, allowRetry = true) {
  if (!bridgeToken || !appConnected) {
    const connected = await ensureBridgeConnection(true);
    if (!connected) {
      throw new Error('Bridge unavailable');
    }
  }

  let response;
  try {
    response = await fetch(`${APP_BASE_URL}${path}`, {
      method: 'POST',
      headers: getBridgeHeaders(),
      body: JSON.stringify(payload),
    });
  } catch (error) {
    setBridgeStatus('disconnected');
    throw error;
  }

  if ((response.status === 401 || response.status === 403) && allowRetry) {
    setBridgeStatus(response.status === 401 ? 'unauthorized' : 'disconnected');
    await ensureBridgeConnection(true);
    return postToApp(path, payload, false);
  }

  if (!response.ok) {
    setBridgeStatus(response.status === 401 ? 'unauthorized' : 'disconnected');
    throw new Error(`HTTP error! status: ${response.status}`);
  }

  setBridgeStatus('connected');
  return response;
}

async function syncBridgeSession(force = false) {
  const now = Date.now();
  if (!force && now - lastSettingsSync < SETTINGS_SYNC_INTERVAL_MS && appConnected) {
    return appConnected;
  }

  lastSettingsSync = now;

  try {
    const response = await fetch(`${APP_BASE_URL}/api/settings`, {
      headers: bridgeToken ? getBridgeHeaders() : undefined,
    });

    if (response.status === 401 || response.status === 403) {
      setBridgeStatus(response.status === 401 ? 'unauthorized' : 'disconnected');
      return false;
    }

    if (!response.ok) {
      throw new Error(`HTTP error! status: ${response.status}`);
    }

    const data = await response.json();
    
    // 检查响应中是否有 success 标志
    if (data.success === false) {
      console.error('Settings sync failed:', data.error);
      setBridgeStatus('disconnected');
      return false;
    }
    
    // 从多个可能的位置提取数据
    const extensionSettings = data?.extensionSettings || data?.settings || {};
    const bridgeInfo = data?.bridge || {};
    
    const nextDisplayName = sanitizeDisplayName(
      extensionSettings?.displayName || data?.settings?.displayName
    );
    
    // 尝试从多个位置获取 bridge token
    const newBridgeToken = 
      extensionSettings?.bridgeToken || 
      data?.bridgeToken || 
      data?.settings?.bridgeToken;
    
    if (newBridgeToken) {
      saveBridgeToken(newBridgeToken);
    }

    if (nextDisplayName !== displayName) {
      displayName = nextDisplayName;
      chrome.storage.sync.set({ displayName }, () => {
        if (chrome.runtime.lastError) {
          console.error('Error saving display name:', chrome.runtime.lastError);
        }
      });
    }

    // 检查当前扩展是否是已注册的扩展
    if (!isCurrentExtensionSession({ ...data, ...bridgeInfo, extensionSettings })) {
      setBridgeStatus('disconnected');
      return false;
    }

    setBridgeStatus('connected');
    return true;
  } catch (error) {
    setBridgeStatus(error.message?.includes('401') ? 'unauthorized' : 'disconnected');
    if (!error.message?.includes('Failed to fetch') && !error.message?.includes('NetworkError')) {
      console.log('Could not sync bridge session from app:', error);
    }
    return false;
  }
}

async function ensureBridgeConnection(force = false) {
  const registered = await registerWithApp();
  if (!registered) {
    return false;
  }

  const synced = await syncBridgeSession(force);
  if (!synced) {
    return false;
  }

  return true;
}

function sanitizeDisplayName(value) {
  if (typeof value !== 'string') {
    return '';
  }
  return value.trim().replace(/\s+/g, ' ').slice(0, 40);
}

function getAddressName() {
  return displayName || 'there';
}

function debounce(func, wait) {
  let timeout;
  return function executedFunction(...args) {
    clearTimeout(timeout);
    timeout = setTimeout(() => func(...args), wait);
  };
}

function extractDomain(url) {
  try {
    if (!url || url.startsWith('chrome://') || url.startsWith('chrome-extension://')) return null;
    return new URL(url).hostname.replace(/^www\./, '');
  } catch {
    return null;
  }
}

function startTabVisit(tab) {
  if (!tab || !tab.url || tab.url.startsWith('chrome://')) return;
  const domain = extractDomain(tab.url);
  if (!domain) return;

  if (currentVisit) endTabVisit();

  currentVisit = {
    tabId: tab.id,
    url: tab.url,
    title: tab.title || 'Untitled',
    domain,
    startTime: Date.now(),
  };

  tabTracker.startSession(tab.id, tab.url, tab.title);
}

function endTabVisit() {
  if (!currentVisit) return;
  const duration = Date.now() - currentVisit.startTime;
  if (duration > 3000) {
    tabVisitHistory.push({
      ...currentVisit,
      endTime: Date.now(),
      duration,
    });
    if (tabVisitHistory.length > 500) {
      tabVisitHistory = tabVisitHistory.slice(-500);
    }
  }

  tabTracker.endSession(currentVisit.tabId);
  currentVisit = null;
}

async function flushHistoryToApp() {
  if (tabVisitHistory.length === 0) return;
  const toFlush = [...tabVisitHistory];
  tabVisitHistory = [];
  try {
    await postToApp('/api/tabs/history', { history: toFlush });
  } catch {
    setBridgeStatus('disconnected');
    tabVisitHistory = [...toFlush, ...tabVisitHistory].slice(-500);
  }
}

async function syncPomodoroStateToApp() {
  if (!appConnected) return;
  try {
    await postToApp('/api/pomodoro', pomodoroTimer.getState());
  } catch (error) {
    console.error('Error syncing pomodoro to app:', error);
  }
}

// Override pomodoro methods to sync with app
const originalStartFocus = pomodoroTimer.startFocus.bind(pomodoroTimer);
pomodoroTimer.startFocus = function () {
  originalStartFocus();
  syncPomodoroStateToApp();
};

const originalStartBreak = pomodoroTimer.startBreak.bind(pomodoroTimer);
pomodoroTimer.startBreak = function () {
  originalStartBreak();
  syncPomodoroStateToApp();
};

const originalPause = pomodoroTimer.pause.bind(pomodoroTimer);
pomodoroTimer.pause = function () {
  originalPause();
  syncPomodoroStateToApp();
};

const originalResume = pomodoroTimer.resume.bind(pomodoroTimer);
pomodoroTimer.resume = function () {
  originalResume();
  syncPomodoroStateToApp();
};

const originalStop = pomodoroTimer.stop.bind(pomodoroTimer);
pomodoroTimer.stop = function () {
  originalStop();
  syncPomodoroStateToApp();
};

const originalCompleteSession = pomodoroTimer.completeSession.bind(pomodoroTimer);
pomodoroTimer.completeSession = function () {
  originalCompleteSession();
  syncPomodoroStateToApp();
};

async function syncFocusTask() {
  try {
    const response = await fetch(`${APP_BASE_URL}/api/focus-task`);
    if (response.ok) {
      const data = await response.json();
      activeFocusTask = data.focusTask || null;
      if (bridgeStatus !== 'unauthorized') {
        setBridgeStatus('connected');
      }
    }
  } catch {
    setBridgeStatus('disconnected');
  }
}

// Periodically sync settings and reconnect
async function periodicSync() {
  const connected = await ensureBridgeConnection(true);
  if (!connected) {
    return;
  }

  await syncFocusTask();

  // Also try to sync pomodoro from app if available
  try {
    const response = await fetch(`${APP_BASE_URL}/api/pomodoro`);
    if (response.ok) {
      const data = await response.json();
      if (data.state && !pomodoroTimer.isRunning) {
        // Optional: Sync app pomodoro to extension if needed
      }
    }
  } catch {
    // Ignore errors
  }
}

function broadcastStateUpdate() {
  try {
    chrome.runtime.sendMessage({ type: 'STATE_UPDATE' });
  } catch {}
}

function savePauseState() {
  try {
    chrome.storage.sync.set({ isPaused }, () => {
      if (chrome.runtime.lastError) {
        console.error('Error saving pause state:', chrome.runtime.lastError);
      }
    });
  } catch (error) {
    console.error('Error saving pause state:', error);
  }
}

function updateTabActivity(tabId) {
  if (!tabId) {
    return;
  }
  tabActivity[tabId] = Date.now();
  delete tabLastNotified[tabId];

  tabTracker.updateActivity(tabId);
}

function resetTabTimers() {
  const now = Date.now();
  try {
    chrome.tabs.query({ currentWindow: true }, (tabs) => {
      if (chrome.runtime.lastError) {
        console.error('Error querying tabs for reset:', chrome.runtime.lastError);
        return;
      }
      tabs.forEach((tab) => {
        if (tab.id) {
          tabActivity[tab.id] = now;
          delete tabLastNotified[tab.id];
        }
      });
    });
  } catch (error) {
    console.error('Error resetting tab timers:', error);
  }
}

function startChecking() {
  if (checkTimer) {
    clearInterval(checkTimer);
  }
  checkTimer = setInterval(checkInactiveTabs, CHECK_INTERVAL_MS);

  setInterval(flushHistoryToApp, HISTORY_FLUSH_INTERVAL_MS);
  setInterval(periodicSync, BRIDGE_SYNC_INTERVAL_MS);
  setInterval(() => tabTracker.checkTabCount(), 60000);
}

function checkInactiveTabs() {
  if (isPaused) {
    return;
  }

  const now = Date.now();
  try {
    chrome.tabs.query({ currentWindow: true }, (tabs) => {
      if (chrome.runtime.lastError) {
        console.error('Error querying tabs for inactivity check:', chrome.runtime.lastError);
        return;
      }
      tabs.forEach((tab) => {
        if (!tab?.id) {
          return;
        }

        if (!tabActivity[tab.id]) {
          tabActivity[tab.id] = now;
        }

        const inactiveTime = now - tabActivity[tab.id];
        if (inactiveTime < inactivityDuration) {
          return;
        }

        const lastNotified = tabLastNotified[tab.id] || 0;
        if (now - lastNotified >= notificationIntervalDuration) {
          tabLastNotified[tab.id] = now;
          showNotification(tab);
        }
      });
    });
  } catch (error) {
    console.error('Error checking inactive tabs:', error);
  }
}

function createInactiveNotificationMessage(tab) {
  const addressName = getAddressName();
  return {
    action: 'showNotification',
    title: displayName ? `Time to refocus, ${addressName}` : 'Time to refocus',
    body: `"${tab.title || 'Untitled'}" has been inactive for at least ${Math.round(
      inactivityDuration / 60000
    )} minutes.`,
    options: { duration: 5000 },
  };
}

function sendMessageToTab(tabId, message) {
  return new Promise((resolve, reject) => {
    try {
      chrome.tabs.sendMessage(tabId, message, (response) => {
        if (chrome.runtime.lastError) {
          reject(chrome.runtime.lastError);
          return;
        }
        resolve(response);
      });
    } catch (error) {
      reject(error);
    }
  });
}

async function showNotification(tab) {
  const message = createInactiveNotificationMessage(tab);

  if (tab?.id) {
    try {
      await sendMessageToTab(tab.id, message);
      return;
    } catch (error) {}
  }

  try {
    chrome.tabs.query({ active: true, currentWindow: true }, (activeTabs) => {
      if (chrome.runtime.lastError) {
        console.error('Error querying active tab:', chrome.runtime.lastError);
        return;
      }
      if (!activeTabs[0]?.id) {
        return;
      }
      chrome.tabs.sendMessage(activeTabs[0].id, message);
    });
  } catch (error) {
    console.error('Error showing notification:', error);
  }
}

async function syncDisplayNameFromApp(force = false) {
  return syncBridgeSession(force);
}

async function sendTabData() {
  try {
    const [tabsResult, activeTabResult] = await Promise.all([
      new Promise((resolve, reject) => {
        chrome.tabs.query({ currentWindow: true }, (tabs) => {
          if (chrome.runtime.lastError) {
            reject(chrome.runtime.lastError);
            return;
          }
          resolve(tabs);
        });
      }),
      new Promise((resolve, reject) => {
        chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
          if (chrome.runtime.lastError) {
            reject(chrome.runtime.lastError);
            return;
          }
          resolve(tabs);
        });
      }),
    ]);

    const activeTab = activeTabResult[0];
    const tabData = tabsResult.map((tab) => ({
      id: tab.id,
      title: tab.title || 'Untitled',
      url: tab.url || '',
      active: activeTab?.id === tab.id,
    }));

    await postToApp('/api/tabs', { tabs: tabData });
    await syncDisplayNameFromApp();
  } catch (error) {
    setBridgeStatus(error.message?.includes('401') ? 'unauthorized' : 'disconnected');
    if (!error.message?.includes('Failed to fetch') && !error.message?.includes('NetworkError')) {
      console.log('Could not send tab data:', error);
    }
  }
}

const debouncedSendTabData = debounce(sendTabData, 500);

function getPopupState(sendResponse) {
  const now = Date.now();
  try {
    chrome.tabs.query({ currentWindow: true }, (tabs) => {
      if (chrome.runtime.lastError) {
        console.error('Error querying tabs for popup state:', chrome.runtime.lastError);
        sendResponse({
          isPaused,
          inactivityMinutes: inactivityDuration / (60 * 1000),
          tabs: [],
          displayName,
          appConnected,
          bridgeStatus,
          pomodoroState: pomodoroTimer.getState(),
          tabReport: tabTracker.getTimeReport(1),
          googleUser,
        });
        return;
      }

      const tabsInfo = tabs.map((tab) => {
        const lastActive = tabActivity[tab.id] || now;
        const inactiveTime = now - lastActive;

        return {
          id: tab.id,
          title: tab.title || 'Untitled',
          url: tab.url || '',
          active: Boolean(tab.active),
          inactiveTime,
          isInactive: inactiveTime >= inactivityDuration,
        };
      });

      sendResponse({
        isPaused,
        inactivityMinutes: inactivityDuration / (60 * 1000),
        tabs: tabsInfo,
        displayName,
        appConnected,
        bridgeStatus,
        activeFocusTask,
        pomodoroState: pomodoroTimer.getState(),
        tabReport: tabTracker.getTimeReport(1),
        googleUser,
      });
    });
  } catch (error) {
    console.error('Error getting popup state:', error);
    sendResponse({
      isPaused,
      inactivityMinutes: inactivityDuration / (60 * 1000),
      tabs: [],
      displayName,
      appConnected,
      bridgeStatus,
      activeFocusTask,
      pomodoroState: pomodoroTimer.getState(),
      tabReport: tabTracker.getTimeReport(1),
      googleUser,
    });
  }
}

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  try {
    if (
      sender.tab?.id &&
      (message.action === 'tabActivity' || message.action === 'contentScriptReady')
    ) {
      updateTabActivity(sender.tab.id);
      sendResponse({ success: true });
      return;
    }

    if (message.action === 'getState') {
      ensureBridgeConnection(bridgeStatus !== 'connected')
        .catch(() => {})
        .finally(() => {
          getPopupState(sendResponse);
        });
      return true;
    }

    if (message.action === 'pauseTracking') {
      isPaused = true;
      savePauseState();
      endTabVisit();
      broadcastStateUpdate();
      sendResponse({ success: true, isPaused: true });
      return;
    }

    if (message.action === 'resumeTracking') {
      isPaused = false;
      resetTabTimers();
      savePauseState();
      broadcastStateUpdate();
      sendResponse({ success: true, isPaused: false });
      return;
    }

    if (message.action === 'refreshSettings') {
      ensureBridgeConnection(true).then(() => {
        sendResponse({ success: true, displayName, appConnected, bridgeStatus, bridgeToken });
      });
      return true;
    }

    if (message.action === 'syncSettingsToApp') {
      ensureBridgeConnection(true)
        .then(async (connected) => {
          if (!connected) {
            sendResponse({
              success: false,
              error: 'Helpy app is unavailable',
              bridgeStatus,
            });
            return;
          }

          const response = await postToApp('/api/settings', message.payload || {});
          const result = await response.json();
          sendResponse({
            success: true,
            settings: result.settings,
            bridgeStatus,
          });
        })
        .catch((error) => {
          sendResponse({ success: false, error: error.message, bridgeStatus });
        });
      return true;
    }

    if (message.action === 'pomodoroStart') {
      pomodoroTimer.startFocus();
      sendResponse({ success: true, state: pomodoroTimer.getState() });
      return;
    }

    if (message.action === 'pomodoroPause') {
      pomodoroTimer.pause();
      sendResponse({ success: true, state: pomodoroTimer.getState() });
      return;
    }

    if (message.action === 'pomodoroResume') {
      pomodoroTimer.resume();
      sendResponse({ success: true, state: pomodoroTimer.getState() });
      return;
    }

    if (message.action === 'pomodoroStop') {
      pomodoroTimer.stop();
      sendResponse({ success: true, state: pomodoroTimer.getState() });
      return;
    }

    if (message.action === 'pomodoroBreak') {
      pomodoroTimer.startBreak();
      sendResponse({ success: true, state: pomodoroTimer.getState() });
      return;
    }

    if (message.action === 'getPomodoroState') {
      sendResponse({ success: true, state: pomodoroTimer.getState() });
      return;
    }

    if (message.action === 'openReports') {
      chrome.tabs.create({
        url: 'reports.html',
      });
      sendResponse({ success: true });
      return;
    }

    // Google Auth actions
    if (message.action === 'googleLogin') {
      googleLogin().then(sendResponse);
      return true; // Indicate async response
    }

    if (message.action === 'googleLogout') {
      googleLogout().then(sendResponse);
      return true;
    }

    if (message.action === 'getGoogleUser') {
      sendResponse({ success: true, user: googleUser });
      return;
    }
  } catch (error) {
    console.error('Error handling message:', error);
    sendResponse({ success: false, error: error.message });
  }
});

chrome.tabs.onActivated.addListener((activeInfo) => {
  try {
    updateTabActivity(activeInfo.tabId);
    chrome.tabs.get(activeInfo.tabId, (tab) => {
      if (chrome.runtime.lastError) return;
      endTabVisit();
      startTabVisit(tab);
      broadcastStateUpdate();
    });
    debouncedSendTabData();
  } catch (error) {
    console.error('Error handling tab activation:', error);
  }
});

chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
  try {
    updateTabActivity(tabId);
    if (changeInfo.status === 'complete' && tab.active) {
      endTabVisit();
      startTabVisit(tab);
      broadcastStateUpdate();
    }
    debouncedSendTabData();
  } catch (error) {
    console.error('Error handling tab update:', error);
  }
});

chrome.tabs.onCreated.addListener((tab) => {
  try {
    if (tab.id) {
      updateTabActivity(tab.id);
    }
    debouncedSendTabData();
    tabTracker.checkTabCount();
  } catch (error) {
    console.error('Error handling tab creation:', error);
  }
});

chrome.tabs.onRemoved.addListener((tabId) => {
  try {
    if (currentVisit && currentVisit.tabId === tabId) {
      endTabVisit();
    }
    delete tabActivity[tabId];
    delete tabLastNotified[tabId];
    broadcastStateUpdate();
    debouncedSendTabData();
  } catch (error) {
    console.error('Error handling tab removal:', error);
  }
});

chrome.windows.onFocusChanged.addListener((windowId) => {
  if (windowId === chrome.windows.WINDOW_ID_NONE) {
    return;
  }

  try {
    chrome.tabs.query({ active: true, windowId }, (tabs) => {
      if (chrome.runtime.lastError) {
        console.error('Error querying active tab on window focus:', chrome.runtime.lastError);
        return;
      }
      if (tabs[0]?.id) {
        updateTabActivity(tabs[0].id);
        debouncedSendTabData();
      }
    });
  } catch (error) {
    console.error('Error handling window focus change:', error);
  }
});

async function registerWithApp() {
  try {
    if (typeof chrome === 'undefined' || !chrome || !chrome.runtime || !chrome.runtime.id) {
      console.warn('Chrome runtime not available, cannot register with app');
      return false;
    }
    const extensionId = chrome.runtime.id;
    if (!extensionId) {
      return false;
    }

    const response = await fetch(`${APP_BASE_URL}/api/extension/register`, {
      method: 'POST',
      headers: getBridgeHeaders(),
      body: JSON.stringify({ extensionId }),
    });

    if (response.ok) {
      const data = await response.json();
      
      // 检查响应是否表示成功
      if (data.success === false) {
        console.error('Extension registration failed:', data.error);
        setBridgeStatus('disconnected');
        return false;
      }
      
      // 从多个可能的位置提取 bridge token
      const newBridgeToken = 
        data.bridgeToken || 
        data.extensionSettings?.bridgeToken ||
        data.settings?.bridgeToken;
        
      if (newBridgeToken && newBridgeToken !== bridgeToken) {
        saveBridgeToken(newBridgeToken);
      }
      
      // 检查当前扩展是否是已注册的扩展
      if (!isCurrentExtensionSession(data)) {
        setBridgeStatus('disconnected');
        return false;
      }
      
      // 如果注册成功，立即同步会话
      await syncBridgeSession(true);
      return true;
    }
    setBridgeStatus(response.status === 401 ? 'unauthorized' : 'disconnected');
    return false;
  } catch (error) {
    setBridgeStatus('disconnected');
    console.log('Could not register extension with app:', error);
    return false;
  }
}

// Only run immediate initialization in real Chrome extension context, not in tests
if (typeof module === 'undefined' || !module.exports) {
  ensureBridgeConnection(true)
    .then((connected) => {
      if (connected) {
        return sendTabData();
      }
      return false;
    })
    .catch(() => {});
}

chrome.runtime.onStartup.addListener(() => {
  ensureBridgeConnection(true)
    .then((connected) => {
      if (connected) {
        return sendTabData();
      }
      return false;
    })
    .catch(() => {});
});

let commandHandler = new CommandHandler({ dataTrackingManager });

if (chrome.omnibox) {
  chrome.omnibox.onInputChanged.addListener((text, suggest) => {
    const suggestions = commandHandler.getSuggestions(text);
    suggest(
      suggestions.map((s) => ({
        content: s.content,
        description: s.description,
      }))
    );
  });

  chrome.omnibox.onInputEntered.addListener(async (text) => {
    const result = await commandHandler.handleCommand(text);

    if (result.action === 'showNotification' && result.title) {
      chrome.notifications.create({
        type: 'basic',
        iconUrl: 'icon.png',
        title: result.title,
        message: result.message,
        priority: 2,
      });
    }
  });
}

if (chrome.commands) {
  chrome.commands.onCommand.addListener((command) => {
    if (command === 'toggle-tracking') {
      isPaused = !isPaused;
      if (isPaused) {
        endTabVisit();
      } else {
        resetTabTimers();
      }
      savePauseState();
      broadcastStateUpdate();
    } else if (command === 'toggle-pomodoro') {
      if (pomodoroTimer.isRunning) {
        pomodoroTimer.pause();
      } else {
        pomodoroTimer.startFocus();
      }
    } else if (command === 'open-reports') {
      chrome.tabs.create({
        url: 'reports.html',
      });
    }
  });
}

chrome.alarms.onAlarm.addListener((alarm) => {
  if (alarm.name === 'pomodoro-complete') {
    pomodoroTimer.completeSession();
  }
});

// For testing purposes (only if needed)
if (typeof module !== 'undefined' && module.exports) {
  module.exports = {
    CommandHandler,
    createInactiveNotificationMessage,
    dataTrackingManager,
    ensureBridgeConnection,
    registerWithApp,
    sanitizeDisplayName,
    syncBridgeSession,
    syncDisplayNameFromApp,
    updateTabActivity,
    applyStoredSettings,
    startChecking,
    tabTracker,
    pomodoroTimer,
    __testing: {
      getState() {
        return {
          activeFocusTask,
          appConnected,
          bridgeStatus,
          bridgeToken,
          displayName,
          isPaused,
          tabActivity: { ...tabActivity },
          tabVisitHistory: [...tabVisitHistory],
        };
      },
      setBridgeStatus,
      setBridgeToken(value) {
        bridgeToken = sanitizeBridgeToken(value);
      },
      setDisplayName(value) {
        displayName = sanitizeDisplayName(value);
      },
      async init() {
        // Simulate the top-level initialization
        // 1. Load Google auth (noop in test)
        // 2. Load sync settings and initialize
        const syncResult = await chrome.storage.sync.get([
          'inactivityMinutes', 
          'notificationIntervalMinutes', 
          'isPaused', 
          'displayName', 
          'bridgeToken'
        ]);
        applyStoredSettings(syncResult);
        startChecking();
        await syncDisplayNameFromApp(true);
        // tabTracker.init() and pomodoroTimer.init() are async, so wait for them
        await tabTracker.init();
        await pomodoroTimer.init();
      }
    },
  };
}
